'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "e395f2950636fba0d4b918a5aad796bb",
"assets/assets/icon/all.png": "01a2edbe183f44a4a71363922923e57e",
"assets/assets/icon/broswer.png": "7342c1ff7bf6c5e54bcf036ab2bb4720",
"assets/assets/icon/camera.png": "b943cd9264948541f15cf7d3eea393db",
"assets/assets/icon/computer.png": "c2e1a9d3a34274b137049963a6e80099",
"assets/assets/icon/doc.png": "ed8c5ad855469844edeee60a5e94acd6",
"assets/assets/icon/file.png": "cdf57c864fca5ab91f20714979cf944d",
"assets/assets/icon/file_sel.png": "124ceb54125830fd268bca955dc5b3a2",
"assets/assets/icon/gallery.png": "291531f5adc726426d0a2c41e9f0f11d",
"assets/assets/icon/homev2.png": "e640b07c6ebbd2958dfa665e8f05a60d",
"assets/assets/icon/homev2_sel.png": "82d19ce637047354d7deff9db572ae20",
"assets/assets/icon/mp3.png": "de0cbb72843a3e75ea066dbe66aafe69",
"assets/assets/icon/other.png": "fa4e1381056bef3531e7fdc1e333e0c2",
"assets/assets/icon/pdf.png": "dacab1b579ca26df5a6337a03c335bb9",
"assets/assets/icon/person.png": "f3099890ddffa6e189e21cb3945e3b38",
"assets/assets/icon/phone.png": "c2a8483d04cfd4e6fe15159da5ff3d1b",
"assets/assets/icon/ppt.png": "ec7584d1109b56dcdc126c459e0024d0",
"assets/assets/icon/qr.png": "67891b40c5bbc3a3b7a9536b1c00e867",
"assets/assets/icon/remote_file.png": "7262616348a25cbce337cfcd732d10ea",
"assets/assets/icon/setting.png": "f6fa8d8f4d2514f40bbdccb12375fa2a",
"assets/assets/icon/upload.png": "0c673333eeb79e79e4243505a3c30795",
"assets/assets/icon/video.png": "d58e25fa75ce0e47aa287c98e5741a26",
"assets/assets/icon/zip.png": "90a6d7abad66aaa21038d12ef2d7d085",
"assets/assets/privacy_policy.md": "80cdae244593b0fd680f93df2d98a6b6",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "95db9098c58fd6db106f1116bae85a0b",
"assets/NOTICES": "47e5ce7ca8c97d71abb92c094a4d453b",
"assets/packages/app_manager/assets/app.svg": "312d95b6c76efda871157c435afda830",
"assets/packages/app_manager/assets/backup.svg": "fb6b3ab3426bd0ad7365ccf80c55522c",
"assets/packages/app_manager/assets/backup2.svg": "f504e128ba0623a0550353c5e847f87e",
"assets/packages/app_manager/assets/icon.svg": "3178db84d2c2577dc25b227ebb78c2f1",
"assets/packages/app_manager/assets/icon2.svg": "79e5780ccec86f49597401d28fc4b48d",
"assets/packages/app_manager/assets/icon3.svg": "ab3d79d2fc1e3060ced27fd37b305cb7",
"assets/packages/app_manager/assets/market.svg": "37ea0ecceafef5f1c9bf78f14a2ab2b5",
"assets/packages/app_manager/assets/market1.svg": "c2c401aefafead847b8bd3487658c00c",
"assets/packages/app_manager/assets/placeholder.png": "20e3eab1f391f45a8b468078fd5529c9",
"assets/packages/app_manager/assets/safe.svg": "51f3af0a2e2c75e46ce47b78d31e553e",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/file_manager_view/assets/icon/add2.svg": "a3f92adf6a7d2586778d251f5385ab6b",
"assets/packages/file_manager_view/assets/icon/camera.png": "b943cd9264948541f15cf7d3eea393db",
"assets/packages/file_manager_view/assets/icon/computer.png": "c2e1a9d3a34274b137049963a6e80099",
"assets/packages/file_manager_view/assets/icon/controller.svg": "b01d2c51e3e2ebf3cb7b80e79dc54ac4",
"assets/packages/file_manager_view/assets/icon/dir.png": "96ee55de4829a938854cd595249df03c",
"assets/packages/file_manager_view/assets/icon/dir.svg": "f5d69a02a25ae44544cbf1fa8c6986df",
"assets/packages/file_manager_view/assets/icon/directory.svg": "9bb4ee942949da6eea98deb3adc0482f",
"assets/packages/file_manager_view/assets/icon/doc.png": "ed8c5ad855469844edeee60a5e94acd6",
"assets/packages/file_manager_view/assets/icon/document.svg": "687ce51f2df936d46e6ce7cb8981325c",
"assets/packages/file_manager_view/assets/icon/download.svg": "685ea1243474914a89755e7bd6c097c2",
"assets/packages/file_manager_view/assets/icon/file.png": "cdf57c864fca5ab91f20714979cf944d",
"assets/packages/file_manager_view/assets/icon/file.svg": "7f237b0ac22eec993d142461a22948a7",
"assets/packages/file_manager_view/assets/icon/file_sel.png": "124ceb54125830fd268bca955dc5b3a2",
"assets/packages/file_manager_view/assets/icon/gallery.png": "291531f5adc726426d0a2c41e9f0f11d",
"assets/packages/file_manager_view/assets/icon/home.png": "84df2635de470652fc473538b6245095",
"assets/packages/file_manager_view/assets/icon/home_sel.png": "31eb44a59ab29e71ab7bd7643d0e8dc2",
"assets/packages/file_manager_view/assets/icon/mp3.png": "de0cbb72843a3e75ea066dbe66aafe69",
"assets/packages/file_manager_view/assets/icon/other.png": "fa4e1381056bef3531e7fdc1e333e0c2",
"assets/packages/file_manager_view/assets/icon/pdf.png": "dacab1b579ca26df5a6337a03c335bb9",
"assets/packages/file_manager_view/assets/icon/phone.png": "c2a8483d04cfd4e6fe15159da5ff3d1b",
"assets/packages/file_manager_view/assets/icon/plugin.svg": "cdc2a07034457bd9e3e86834651ed527",
"assets/packages/file_manager_view/assets/icon/ppt.png": "ec7584d1109b56dcdc126c459e0024d0",
"assets/packages/file_manager_view/assets/icon/qr.png": "67891b40c5bbc3a3b7a9536b1c00e867",
"assets/packages/file_manager_view/assets/icon/QR_code.svg": "fa5826c86f67c800e7167d06d58851eb",
"assets/packages/file_manager_view/assets/icon/recycle.svg": "5fd5b496452ca0ec94bcb30eb125a3ca",
"assets/packages/file_manager_view/assets/icon/terminal-box-fill.svg": "fcc173eb4ca43faf6932472c338b0add",
"assets/packages/file_manager_view/assets/icon/upload.png": "0c673333eeb79e79e4243505a3c30795",
"assets/packages/file_manager_view/assets/icon/video.png": "d58e25fa75ce0e47aa287c98e5741a26",
"assets/packages/file_manager_view/assets/icon/zip.png": "90a6d7abad66aaa21038d12ef2d7d085",
"assets/packages/file_manager_view/assets/icon/zip.svg": "4392a6e377aa51812844ff4fc8ea08a5",
"assets/packages/global_repository/assets/icon/connect.svg": "aa280cb7d98289e5f84fca79e384ed6f",
"assets/packages/global_repository/assets/icon/lan.svg": "f9bd4d0f573d34e59a150769c3dac122",
"assets/packages/global_repository/assets/icon/qr_code.svg": "7b321e94a38f8b6298f2be7580b2231a",
"assets/packages/global_repository/assets/icon/remote.svg": "2b57255f33ef8119324b5bed2f460daa",
"assets/packages/wakelock_web/assets/no_sleep.js": "7748a45cd593f33280669b29c2c8919a",
"assets/packages/window_manager/images/ic_chrome_close.png": "75f4b8ab3608a05461a31fc18d6b47c2",
"assets/packages/window_manager/images/ic_chrome_maximize.png": "af7499d7657c8b69d23b85156b60298c",
"assets/packages/window_manager/images/ic_chrome_minimize.png": "4282cd84cb36edf2efb950ad9269ca62",
"assets/packages/window_manager/images/ic_chrome_unmaximize.png": "4a90c1909cb74e8f0d35794e2f61d8bf",
"favicon.png": "a19a902de8d2ab8cddd2d146ef1f1385",
"flutter.js": "eb2682e33f25cd8f1fc59011497c35f8",
"icons/Icon-192.png": "b4910f013751cbe50f96bec1acdbed19",
"icons/Icon-512.png": "0b3e421d58b1bd73e7194ee80bd1d9b8",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "82bc723c9722459b7af29af92c985a7e",
"/": "82bc723c9722459b7af29af92c985a7e",
"main.dart.js": "ea783de836d0d6b433d5cf612dcd7565",
"manifest.json": "26909e2edd8d6592dd3fc99ee6c8fb94",
"version.json": "c53c2e91066204f5d6e14bd8a713ac23"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
