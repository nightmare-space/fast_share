'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "40022115f865149a0f7dc294f35cf40b",
"index.html": "a99f830869c8d069ba479718eeaca36a",
"/": "a99f830869c8d069ba479718eeaca36a",
"main.dart.js": "0389b30d7a4b44c1753cf4ff15a317f0",
"favicon.png": "a19a902de8d2ab8cddd2d146ef1f1385",
"icons/Icon-192.png": "b4910f013751cbe50f96bec1acdbed19",
"icons/Icon-512.png": "0b3e421d58b1bd73e7194ee80bd1d9b8",
"manifest.json": "d18d511e5a61de7de23541feb92f043d",
"assets/AssetManifest.json": "9304d319ee860a8d1422011aca29dc90",
"assets/NOTICES": "9b194b1a4e74ca6afc00f4f29d11d7fb",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/global_repository/assets/icon/connect.svg": "a9561288dcd60e07597dd60b70ff1ece",
"assets/packages/global_repository/assets/icon/remote.svg": "017a806d9ba7d06dfa1019a552492514",
"assets/packages/global_repository/assets/icon/lan.svg": "ed70f6f4c3caa63a82281ef55222be6d",
"assets/packages/global_repository/assets/icon/qr_code.svg": "ff8eb3050969efffc6fdba8d740c2f97",
"assets/packages/file_manager_view/assets/icon/plugin.svg": "fe7ef4f7d2b4cb11de20691b5d37ad3f",
"assets/packages/file_manager_view/assets/icon/file.svg": "b689f6685cc5d163a35aac2f7abb6902",
"assets/packages/file_manager_view/assets/icon/terminal-box-fill.svg": "2ff700a72e5b515a59e80989995e29bd",
"assets/packages/file_manager_view/assets/icon/zip.svg": "e356218090b4023df62e3ad2417ca15e",
"assets/packages/file_manager_view/assets/icon/controller.svg": "21b920b1fe6b4ab5ac4cc5eb4c77412a",
"assets/packages/file_manager_view/assets/icon/directory.svg": "837b5d954329bcb63773460140414750",
"assets/packages/app_manager/assets/backup.svg": "268c4e925444592576377a26f7188493",
"assets/packages/app_manager/assets/market1.svg": "993047def11073c8fdf68ec103d847c9",
"assets/packages/app_manager/assets/safe.svg": "aaf57d7a035ad8a2dba6817536ac8efd",
"assets/packages/app_manager/assets/backup2.svg": "d6dbe9a3697e426e695e5c9c97c9b8a0",
"assets/packages/app_manager/assets/app.svg": "b9469f0382910382511d97ffacc4e5be",
"assets/packages/app_manager/assets/icon.svg": "ef49f494cb40978574c3910510de7ab9",
"assets/packages/app_manager/assets/placeholder.png": "20e3eab1f391f45a8b468078fd5529c9",
"assets/packages/app_manager/assets/market.svg": "61903214915d6999ab1c56e2e4554469",
"assets/packages/app_manager/assets/icon2.svg": "9e16ec5b1aa38ac2875321eb83eb931c",
"assets/packages/app_manager/assets/icon3.svg": "5518e7d4ea9cc7270ad1bed9a70999f5",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/assets/icon/file.svg": "3d6b7f6a7dc7f15f2eec6c7ed225891f",
"assets/assets/icon/QR_code.svg": "ab99a6d6a7270198436770794142330a",
"assets/assets/icon/directory.svg": "7823ffaaf5f4b64399cc6312666562c0"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
